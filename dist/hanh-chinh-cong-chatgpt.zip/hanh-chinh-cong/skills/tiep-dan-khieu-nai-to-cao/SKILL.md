---
name: tiep-dan-khieu-nai-to-cao
description: Hỗ trợ công tác tiếp công dân, xử lý đơn và giải quyết khiếu nại, tố cáo, kiến nghị phản ánh tại cơ quan hành chính nhà nước, nhất là UBND cấp xã — phân loại đơn (khiếu nại, tố cáo, kiến nghị phản ánh, đơn có nhiều nội dung, đơn trùng, đơn không đủ điều kiện), xác định thẩm quyền sau sắp xếp chính quyền 2 cấp, tính hạn thụ lý và hạn giải quyết theo Luật sửa đổi số 136/2025/QH15 (hiệu lực 01/7/2026) hoặc quy định trước đó, soạn phiếu chuyển đơn, văn bản hướng dẫn, thông báo thụ lý/không thụ lý, biên bản làm việc, biên bản đối thoại, quyết định giải quyết khiếu nại, kết luận nội dung tố cáo, sổ tiếp công dân, bảo vệ thông tin người tố cáo. Dùng khi người dùng nói "xử lý đơn khiếu nại", "đơn tố cáo", "thời hạn giải quyết khiếu nại", "thông báo thụ lý", "quyết định giải quyết khiếu nại lần đầu", "kết luận tố cáo", "tiếp công dân", "đơn kiến nghị phản ánh".
---

# Tiếp công dân – khiếu nại – tố cáo

Đọc trước: `references/nguyen-tac-chung.md`, `references/the-thuc-nd30.md`, `references/mau-khieu-nai-to-cao.md`.

> Luật số 136/2025/QH15 sửa đổi Luật Tiếp công dân, Luật Khiếu nại, Luật Tố cáo có hiệu lực **01/7/2026**; Nghị định 155/2026/NĐ-CP hướng dẫn. Nguồn thứ cấp nêu thời hạn thụ lý khiếu nại rút từ 10 ngày còn 7 ngày (làm việc). Mọi thời hạn theo luật mới gắn **[Cần kiểm tra]** cho đến khi đối chiếu văn bản gốc. Đơn thư có dữ liệu cá nhân: chỉ đưa phần cần thiết; **thông tin người tố cáo phải được giữ bí mật**.

## 1. Phân loại đơn (bảng xử lý)
| Loại | Dấu hiệu | Hướng xử lý |
|---|---|---|
| Khiếu nại | Đề nghị xem xét lại quyết định hành chính, hành vi hành chính, quyết định kỷ luật xâm phạm quyền, lợi ích **của chính người khiếu nại** | Thuộc thẩm quyền → thụ lý; không thuộc → hướng dẫn gửi đúng cơ quan (không chuyển đơn khiếu nại) |
| Tố cáo | Báo cho cơ quan biết hành vi **vi phạm pháp luật** của cơ quan, tổ chức, cá nhân gây thiệt hại lợi ích nhà nước, quyền lợi người khác | Thuộc thẩm quyền → xem xét thụ lý; không thuộc → chuyển đơn đến cơ quan có thẩm quyền, thông báo người tố cáo (nếu có địa chỉ) |
| Kiến nghị, phản ánh | Góp ý, đề xuất, phản ánh tình hình | Xem xét, trả lời hoặc chuyển cơ quan có trách nhiệm |
| Đơn nhiều nội dung | Vừa khiếu nại vừa tố cáo | Tách nội dung, xử lý theo từng loại |
| Đơn nặc danh, mạo danh, không rõ người tố cáo | | Xử lý theo quy định về tố cáo không rõ người tố cáo (có thể xem xét nếu nội dung rõ, có tài liệu, chứng cứ cụ thể) [Cần kiểm tra sau sửa đổi] |
| Đơn trùng, đã giải quyết đúng pháp luật | | Không thụ lý lại; trả lời/lưu theo quy định |

## 2. Thẩm quyền (chính quyền 2 cấp)
Quyết định/hành vi của Chủ tịch UBND xã, công chức xã → Chủ tịch UBND xã giải quyết lần đầu; lần hai → Chủ tịch UBND cấp tỉnh hoặc thủ trưởng cơ quan chuyên môn theo luật sửa đổi [Cần kiểm tra – trước đây lần hai do Chủ tịch UBND huyện, nay không còn cấp huyện]. Không chắc thẩm quyền → nêu các khả năng, khuyến nghị hỏi Thanh tra tỉnh.

## 3. Thời hạn
`thoi_han_khieu_nai_to_cao` (loại, ngày nhận đơn, ngày thụ lý, phức tạp, vùng sâu vùng xa, số lần gia hạn) – công cụ tự chọn quy định trước/từ 01/7/2026 theo ngày nhận đơn và trả nhãn tin cậy. Thời hiệu khiếu nại: 90 ngày kể từ ngày nhận được/biết quyết định, hành vi hành chính. Lập lịch nhắc bằng `tao_file_ics`.

## 4. Quy trình giải quyết khiếu nại lần đầu (khung)
Thụ lý (thông báo thụ lý) → kiểm tra lại quyết định/hành vi bị khiếu nại hoặc giao xác minh → xác minh (làm việc, thu thập chứng cứ, biên bản) → **đối thoại** (bắt buộc khi kết quả xác minh khác yêu cầu của người khiếu nại – lập biên bản đối thoại) → quyết định giải quyết khiếu nại (nội dung bắt buộc – mẫu trong references) → gửi, công khai quyết định.

## 5. Quy trình giải quyết tố cáo (khung)
Thụ lý → xác minh nội dung tố cáo → kết luận nội dung tố cáo → xử lý kết luận (xử lý vi phạm, kiến nghị) → công khai kết luận theo quy định; **bảo vệ người tố cáo** (giữ bí mật họ tên, địa chỉ, bút tích).

## 6. Tiếp công dân
Lịch tiếp định kỳ của người đứng đầu (Chủ tịch UBND cấp xã tiếp định kỳ ít nhất 01 ngày trong tuần theo Luật Tiếp công dân 2013 [Cần kiểm tra sau sửa đổi 2025]); sổ tiếp công dân: `STT | Ngày | Họ tên, địa chỉ | Nội dung | Phân loại | Hướng xử lý | Người tiếp | Ghi chú`; từ chối tiếp trong các trường hợp luật định (say rượu, gây rối...). Đoàn đông người: cử đại diện.

## Đầu ra
Phân loại + hướng xử lý từng đơn · thẩm quyền (có nhãn) · lịch thời hạn · văn bản nháp (phiếu chuyển, hướng dẫn, thông báo thụ lý, biên bản, quyết định, kết luận) · lưu ý bảo mật.

<!-- KET-NOI:BAT-DAU (sinh tự động từ scripts/ket_noi.json – sửa ở đó rồi chạy build) -->
## Kết nối ứng dụng

Connector dùng cho skill này: **Google Calendar** · **Google Drive** · **Microsoft 365 (Outlook, OneDrive/SharePoint, Teams)**. Đọc quy tắc trong `references/ket-noi.md` trước khi dùng.

1. Tạo nhắc mốc thời hạn: thụ lý, giải quyết, gia hạn (tính bằng công cụ) trên lịch người được giao – tiêu đề chỉ ghi số đơn, không ghi tên người khiếu nại, tố cáo.
2. Lưu dự thảo thông báo thụ lý, quyết định, kết luận vào thư mục có giới hạn quyền; hồ sơ tố cáo không lưu lên dịch vụ đám mây nếu quy chế cơ quan không cho phép.

**Khi chưa kết nối:** làm đủ phần soạn thảo, tính toán; đưa nội dung sẵn để người dùng tự dán vào email, lịch, thư mục; nhắc **một lần** cách bật connector, không dừng việc chỉ vì chưa kết nối.
<!-- KET-NOI:KET-THUC -->
